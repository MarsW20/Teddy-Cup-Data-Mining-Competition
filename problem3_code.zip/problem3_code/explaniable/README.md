"""
    请在阅读代码之前阅读本文件。
"""

## 生成信息熵

python entropy.py

## 生成可解释性

python main.py

