"""
    请在阅读代码之前阅读本文件。
"""

# 基于TF-IDF的中文关键词提取

# 生成idf,保存至idf.txt

    python gen_idf.py

# 生成词汇表并画出出饼状图,res.txt为所有留言回复的相关性
    python tf_idf.py

